import { useMemo } from 'react';

import AddIcon from '@mui/icons-material/Add';
import RefreshIcon from '@mui/icons-material/Refresh';

import {
    Alert,
    Box,
    Button,
    CircularProgress,
    Stack,
    Typography
} from '@mui/material';

import CustomDataGridTs
    from '@/componentesCommons/DataGridCommon/CustomDataGridTs';

import { useAgenciasTomaFisicaInventario }
    from '@/pages/Inventario/hooks/useAgenciasTomaFisicaInventarioHook';
import { crearAgenciasTomaFisicaInventarioColumns } from '@/pages/Inventario/configs/agenciaColumns';
import AgenciasTomaFisicaInventarioFormDialog from '@/pages/Inventario/components/AgenciaFormDialog';



const AgenciasTomaFisicaInventarioPage = () => {

    const {
        agencias,
        empresas,
        agenciaSeleccionada,
        formularioAbierto,
        cargando,
        guardando,
        error,
        abrirNuevo,
        abrirEditar,
        cerrarFormulario,
        guardarAgencia,
        cargarDatos
    } = useAgenciasTomaFisicaInventario();

    const columns = useMemo(
        () =>
            crearAgenciasTomaFisicaInventarioColumns(
                abrirEditar
            ),
        [abrirEditar]
    );

    return (
        <Box sx={{ p: 2 }}>
            <Stack
                direction={{
                    xs: 'column',
                    sm: 'row'
                }}
                alignItems={{
                    xs: 'stretch',
                    sm: 'center'
                }}
                justifyContent="space-between"
                spacing={1.5}
                mb={2}
            >
                <Box>
                    <Typography variant="h5" fontWeight={600}>
                        Agencias
                    </Typography>

                    <Typography
                        variant="body2"
                        color="text.secondary"
                    >
                        Administración de agencias para toma física de inventario
                    </Typography>
                </Box>

                <Stack direction="row" spacing={1}>
                    <Button
                        variant="outlined"
                        startIcon={<RefreshIcon />}
                        onClick={() => void cargarDatos()}
                        disabled={cargando}
                    >
                        Actualizar
                    </Button>

                    <Button
                        variant="contained"
                        startIcon={<AddIcon />}
                        onClick={abrirNuevo}
                    >
                        Nueva agencia
                    </Button>
                </Stack>
            </Stack>

            {error && (
                <Alert severity="error" sx={{ mb: 2 }}>
                    {error}
                </Alert>
            )}

            {cargando ? (
                <Box
                    display="flex"
                    justifyContent="center"
                    py={6}
                >
                    <CircularProgress size={32} />
                </Box>
            ) : (
                <CustomDataGridTs
                    gridId="agencias-toma-fisica-inventario-grid"
                    rows={agencias}
                    columns={columns}
                    getRowId={row => row.id}
                    addNumeration
                    hasFilters
                    hasPagination
                    pageSizes={[5, 10, 20]}
                    initialPageSize={10}
                    titleEmptyTable="No existen agencias registradas"
                    searchLabel="Buscar"
                />
            )}

            <AgenciasTomaFisicaInventarioFormDialog
                open={formularioAbierto}
                agencia={agenciaSeleccionada}
                empresas={empresas}
                guardando={guardando}
                onClose={cerrarFormulario}
                onGuardar={guardarAgencia}
            />
        </Box>
    );
};

export default AgenciasTomaFisicaInventarioPage;